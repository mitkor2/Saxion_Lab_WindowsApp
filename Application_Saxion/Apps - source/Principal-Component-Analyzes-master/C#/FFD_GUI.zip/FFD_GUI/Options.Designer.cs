﻿namespace FFD_GUI
{
    partial class Options
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Options));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.richTextBox3 = new System.Windows.Forms.RichTextBox();
            this.richTextBox4 = new System.Windows.Forms.RichTextBox();
            this.richTextBox5 = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.richTextBox6 = new System.Windows.Forms.RichTextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.richTextBox7 = new System.Windows.Forms.RichTextBox();
            this.richTextBox8 = new System.Windows.Forms.RichTextBox();
            this.richTextBox9 = new System.Windows.Forms.RichTextBox();
            this.richTextBox10 = new System.Windows.Forms.RichTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.richTextBox11 = new System.Windows.Forms.RichTextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.richTextBox12 = new System.Windows.Forms.RichTextBox();
            this.richTextBox13 = new System.Windows.Forms.RichTextBox();
            this.richTextBox14 = new System.Windows.Forms.RichTextBox();
            this.richTextBox15 = new System.Windows.Forms.RichTextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.richTextBox16 = new System.Windows.Forms.RichTextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.richTextBox17 = new System.Windows.Forms.RichTextBox();
            this.richTextBox18 = new System.Windows.Forms.RichTextBox();
            this.richTextBox19 = new System.Windows.Forms.RichTextBox();
            this.richTextBox20 = new System.Windows.Forms.RichTextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.richTextBox21 = new System.Windows.Forms.RichTextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.richTextBox22 = new System.Windows.Forms.RichTextBox();
            this.richTextBox23 = new System.Windows.Forms.RichTextBox();
            this.richTextBox24 = new System.Windows.Forms.RichTextBox();
            this.richTextBox25 = new System.Windows.Forms.RichTextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.richTextBox26 = new System.Windows.Forms.RichTextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.richTextBox27 = new System.Windows.Forms.RichTextBox();
            this.richTextBox28 = new System.Windows.Forms.RichTextBox();
            this.richTextBox29 = new System.Windows.Forms.RichTextBox();
            this.richTextBox30 = new System.Windows.Forms.RichTextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.richTextBox31 = new System.Windows.Forms.RichTextBox();
            this.button7 = new System.Windows.Forms.Button();
            this.richTextBox32 = new System.Windows.Forms.RichTextBox();
            this.richTextBox33 = new System.Windows.Forms.RichTextBox();
            this.richTextBox34 = new System.Windows.Forms.RichTextBox();
            this.richTextBox35 = new System.Windows.Forms.RichTextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.richTextBox36 = new System.Windows.Forms.RichTextBox();
            this.button8 = new System.Windows.Forms.Button();
            this.richTextBox37 = new System.Windows.Forms.RichTextBox();
            this.richTextBox38 = new System.Windows.Forms.RichTextBox();
            this.richTextBox39 = new System.Windows.Forms.RichTextBox();
            this.richTextBox40 = new System.Windows.Forms.RichTextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.richTextBox41 = new System.Windows.Forms.RichTextBox();
            this.button9 = new System.Windows.Forms.Button();
            this.richTextBox42 = new System.Windows.Forms.RichTextBox();
            this.richTextBox43 = new System.Windows.Forms.RichTextBox();
            this.richTextBox44 = new System.Windows.Forms.RichTextBox();
            this.richTextBox45 = new System.Windows.Forms.RichTextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.richTextBox46 = new System.Windows.Forms.RichTextBox();
            this.button10 = new System.Windows.Forms.Button();
            this.richTextBox47 = new System.Windows.Forms.RichTextBox();
            this.richTextBox48 = new System.Windows.Forms.RichTextBox();
            this.richTextBox49 = new System.Windows.Forms.RichTextBox();
            this.richTextBox50 = new System.Windows.Forms.RichTextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.tableLayoutPanel11 = new System.Windows.Forms.TableLayoutPanel();
            this.richTextBox51 = new System.Windows.Forms.RichTextBox();
            this.button11 = new System.Windows.Forms.Button();
            this.richTextBox52 = new System.Windows.Forms.RichTextBox();
            this.richTextBox53 = new System.Windows.Forms.RichTextBox();
            this.richTextBox54 = new System.Windows.Forms.RichTextBox();
            this.richTextBox55 = new System.Windows.Forms.RichTextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.tableLayoutPanel12 = new System.Windows.Forms.TableLayoutPanel();
            this.richTextBox56 = new System.Windows.Forms.RichTextBox();
            this.button12 = new System.Windows.Forms.Button();
            this.richTextBox57 = new System.Windows.Forms.RichTextBox();
            this.richTextBox58 = new System.Windows.Forms.RichTextBox();
            this.richTextBox59 = new System.Windows.Forms.RichTextBox();
            this.richTextBox60 = new System.Windows.Forms.RichTextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.tableLayoutPanel13 = new System.Windows.Forms.TableLayoutPanel();
            this.richTextBox61 = new System.Windows.Forms.RichTextBox();
            this.button13 = new System.Windows.Forms.Button();
            this.richTextBox62 = new System.Windows.Forms.RichTextBox();
            this.richTextBox63 = new System.Windows.Forms.RichTextBox();
            this.richTextBox64 = new System.Windows.Forms.RichTextBox();
            this.richTextBox65 = new System.Windows.Forms.RichTextBox();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            this.tableLayoutPanel10.SuspendLayout();
            this.tableLayoutPanel11.SuspendLayout();
            this.tableLayoutPanel12.SuspendLayout();
            this.tableLayoutPanel13.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.richTextBox1, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.button1, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.richTextBox2, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.richTextBox3, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.richTextBox4, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.richTextBox5, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label5, 0, 4);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(20, 32);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 6;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(180, 166);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(92, 2);
            this.richTextBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(86, 23);
            this.richTextBox1.TabIndex = 1;
            this.richTextBox1.Text = "";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(92, 137);
            this.button1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(86, 25);
            this.button1.TabIndex = 0;
            this.button1.Text = "Apply";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // richTextBox2
            // 
            this.richTextBox2.Location = new System.Drawing.Point(92, 29);
            this.richTextBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(86, 23);
            this.richTextBox2.TabIndex = 2;
            this.richTextBox2.Text = "";
            // 
            // richTextBox3
            // 
            this.richTextBox3.Location = new System.Drawing.Point(92, 56);
            this.richTextBox3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox3.Name = "richTextBox3";
            this.richTextBox3.Size = new System.Drawing.Size(86, 23);
            this.richTextBox3.TabIndex = 3;
            this.richTextBox3.Text = "";
            // 
            // richTextBox4
            // 
            this.richTextBox4.Location = new System.Drawing.Point(92, 83);
            this.richTextBox4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox4.Name = "richTextBox4";
            this.richTextBox4.Size = new System.Drawing.Size(86, 23);
            this.richTextBox4.TabIndex = 4;
            this.richTextBox4.Text = "";
            // 
            // richTextBox5
            // 
            this.richTextBox5.Location = new System.Drawing.Point(92, 110);
            this.richTextBox5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox5.Name = "richTextBox5";
            this.richTextBox5.Size = new System.Drawing.Size(86, 23);
            this.richTextBox5.TabIndex = 5;
            this.richTextBox5.Text = "";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(2, 0);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 17);
            this.label1.TabIndex = 6;
            this.label1.Text = "Y axis";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(2, 27);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 17);
            this.label2.TabIndex = 7;
            this.label2.Text = "X axis";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(2, 54);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 17);
            this.label3.TabIndex = 8;
            this.label3.Text = "Danger 1";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(2, 81);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 17);
            this.label4.TabIndex = 9;
            this.label4.Text = "Danger 2";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(2, 108);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(67, 17);
            this.label5.TabIndex = 10;
            this.label5.Text = "Danger 3";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.richTextBox6, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.button2, 1, 5);
            this.tableLayoutPanel2.Controls.Add(this.richTextBox7, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.richTextBox8, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.richTextBox9, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.richTextBox10, 1, 4);
            this.tableLayoutPanel2.Controls.Add(this.label6, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.label7, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label8, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.label9, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.label10, 0, 4);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(230, 30);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 6;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(180, 166);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // richTextBox6
            // 
            this.richTextBox6.Location = new System.Drawing.Point(92, 2);
            this.richTextBox6.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox6.Name = "richTextBox6";
            this.richTextBox6.Size = new System.Drawing.Size(86, 23);
            this.richTextBox6.TabIndex = 1;
            this.richTextBox6.Text = "";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(92, 137);
            this.button2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(86, 25);
            this.button2.TabIndex = 0;
            this.button2.Text = "Apply";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // richTextBox7
            // 
            this.richTextBox7.Location = new System.Drawing.Point(92, 29);
            this.richTextBox7.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox7.Name = "richTextBox7";
            this.richTextBox7.Size = new System.Drawing.Size(86, 23);
            this.richTextBox7.TabIndex = 2;
            this.richTextBox7.Text = "";
            // 
            // richTextBox8
            // 
            this.richTextBox8.Location = new System.Drawing.Point(92, 56);
            this.richTextBox8.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox8.Name = "richTextBox8";
            this.richTextBox8.Size = new System.Drawing.Size(86, 23);
            this.richTextBox8.TabIndex = 3;
            this.richTextBox8.Text = "";
            // 
            // richTextBox9
            // 
            this.richTextBox9.Location = new System.Drawing.Point(92, 83);
            this.richTextBox9.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox9.Name = "richTextBox9";
            this.richTextBox9.Size = new System.Drawing.Size(86, 23);
            this.richTextBox9.TabIndex = 4;
            this.richTextBox9.Text = "";
            // 
            // richTextBox10
            // 
            this.richTextBox10.Location = new System.Drawing.Point(92, 110);
            this.richTextBox10.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox10.Name = "richTextBox10";
            this.richTextBox10.Size = new System.Drawing.Size(86, 23);
            this.richTextBox10.TabIndex = 5;
            this.richTextBox10.Text = "";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(2, 0);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 17);
            this.label6.TabIndex = 6;
            this.label6.Text = "Y axis";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(2, 27);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(45, 17);
            this.label7.TabIndex = 7;
            this.label7.Text = "X axis";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(2, 54);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 17);
            this.label8.TabIndex = 8;
            this.label8.Text = "Danger 1";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(2, 81);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(67, 17);
            this.label9.TabIndex = 9;
            this.label9.Text = "Danger 2";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(2, 108);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(67, 17);
            this.label10.TabIndex = 10;
            this.label10.Text = "Danger 3";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.richTextBox11, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.button3, 1, 5);
            this.tableLayoutPanel3.Controls.Add(this.richTextBox12, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.richTextBox13, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this.richTextBox14, 1, 3);
            this.tableLayoutPanel3.Controls.Add(this.richTextBox15, 1, 4);
            this.tableLayoutPanel3.Controls.Add(this.label11, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.label12, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.label13, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.label14, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.label15, 0, 4);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(464, 32);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 6;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(180, 166);
            this.tableLayoutPanel3.TabIndex = 2;
            // 
            // richTextBox11
            // 
            this.richTextBox11.Location = new System.Drawing.Point(92, 2);
            this.richTextBox11.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox11.Name = "richTextBox11";
            this.richTextBox11.Size = new System.Drawing.Size(86, 23);
            this.richTextBox11.TabIndex = 1;
            this.richTextBox11.Text = "";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(92, 137);
            this.button3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(86, 25);
            this.button3.TabIndex = 0;
            this.button3.Text = "Apply";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // richTextBox12
            // 
            this.richTextBox12.Location = new System.Drawing.Point(92, 29);
            this.richTextBox12.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox12.Name = "richTextBox12";
            this.richTextBox12.Size = new System.Drawing.Size(86, 23);
            this.richTextBox12.TabIndex = 2;
            this.richTextBox12.Text = "";
            // 
            // richTextBox13
            // 
            this.richTextBox13.Location = new System.Drawing.Point(92, 56);
            this.richTextBox13.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox13.Name = "richTextBox13";
            this.richTextBox13.Size = new System.Drawing.Size(86, 23);
            this.richTextBox13.TabIndex = 3;
            this.richTextBox13.Text = "";
            // 
            // richTextBox14
            // 
            this.richTextBox14.Location = new System.Drawing.Point(92, 83);
            this.richTextBox14.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox14.Name = "richTextBox14";
            this.richTextBox14.Size = new System.Drawing.Size(86, 23);
            this.richTextBox14.TabIndex = 4;
            this.richTextBox14.Text = "";
            // 
            // richTextBox15
            // 
            this.richTextBox15.Location = new System.Drawing.Point(92, 110);
            this.richTextBox15.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox15.Name = "richTextBox15";
            this.richTextBox15.Size = new System.Drawing.Size(86, 23);
            this.richTextBox15.TabIndex = 5;
            this.richTextBox15.Text = "";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(2, 0);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(45, 17);
            this.label11.TabIndex = 6;
            this.label11.Text = "Y axis";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(2, 27);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(45, 17);
            this.label12.TabIndex = 7;
            this.label12.Text = "X axis";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(2, 54);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(67, 17);
            this.label13.TabIndex = 8;
            this.label13.Text = "Danger 1";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(2, 81);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(67, 17);
            this.label14.TabIndex = 9;
            this.label14.Text = "Danger 2";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(2, 108);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(67, 17);
            this.label15.TabIndex = 10;
            this.label15.Text = "Danger 3";
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Controls.Add(this.richTextBox16, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.button4, 1, 5);
            this.tableLayoutPanel4.Controls.Add(this.richTextBox17, 1, 1);
            this.tableLayoutPanel4.Controls.Add(this.richTextBox18, 1, 2);
            this.tableLayoutPanel4.Controls.Add(this.richTextBox19, 1, 3);
            this.tableLayoutPanel4.Controls.Add(this.richTextBox20, 1, 4);
            this.tableLayoutPanel4.Controls.Add(this.label16, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.label17, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.label18, 0, 2);
            this.tableLayoutPanel4.Controls.Add(this.label19, 0, 3);
            this.tableLayoutPanel4.Controls.Add(this.label20, 0, 4);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(692, 32);
            this.tableLayoutPanel4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 6;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(180, 166);
            this.tableLayoutPanel4.TabIndex = 3;
            // 
            // richTextBox16
            // 
            this.richTextBox16.Location = new System.Drawing.Point(92, 2);
            this.richTextBox16.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox16.Name = "richTextBox16";
            this.richTextBox16.Size = new System.Drawing.Size(86, 23);
            this.richTextBox16.TabIndex = 1;
            this.richTextBox16.Text = "";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(92, 137);
            this.button4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(86, 25);
            this.button4.TabIndex = 0;
            this.button4.Text = "Apply";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // richTextBox17
            // 
            this.richTextBox17.Location = new System.Drawing.Point(92, 29);
            this.richTextBox17.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox17.Name = "richTextBox17";
            this.richTextBox17.Size = new System.Drawing.Size(86, 23);
            this.richTextBox17.TabIndex = 2;
            this.richTextBox17.Text = "";
            // 
            // richTextBox18
            // 
            this.richTextBox18.Location = new System.Drawing.Point(92, 56);
            this.richTextBox18.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox18.Name = "richTextBox18";
            this.richTextBox18.Size = new System.Drawing.Size(86, 23);
            this.richTextBox18.TabIndex = 3;
            this.richTextBox18.Text = "";
            // 
            // richTextBox19
            // 
            this.richTextBox19.Location = new System.Drawing.Point(92, 83);
            this.richTextBox19.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox19.Name = "richTextBox19";
            this.richTextBox19.Size = new System.Drawing.Size(86, 23);
            this.richTextBox19.TabIndex = 4;
            this.richTextBox19.Text = "";
            // 
            // richTextBox20
            // 
            this.richTextBox20.Location = new System.Drawing.Point(92, 110);
            this.richTextBox20.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox20.Name = "richTextBox20";
            this.richTextBox20.Size = new System.Drawing.Size(86, 23);
            this.richTextBox20.TabIndex = 5;
            this.richTextBox20.Text = "";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(2, 0);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(45, 17);
            this.label16.TabIndex = 6;
            this.label16.Text = "Y axis";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(2, 27);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(45, 17);
            this.label17.TabIndex = 7;
            this.label17.Text = "X axis";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(2, 54);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(67, 17);
            this.label18.TabIndex = 8;
            this.label18.Text = "Danger 1";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(2, 81);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(67, 17);
            this.label19.TabIndex = 9;
            this.label19.Text = "Danger 2";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(2, 108);
            this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(67, 17);
            this.label20.TabIndex = 10;
            this.label20.Text = "Danger 3";
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Controls.Add(this.richTextBox21, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.button5, 1, 5);
            this.tableLayoutPanel5.Controls.Add(this.richTextBox22, 1, 1);
            this.tableLayoutPanel5.Controls.Add(this.richTextBox23, 1, 2);
            this.tableLayoutPanel5.Controls.Add(this.richTextBox24, 1, 3);
            this.tableLayoutPanel5.Controls.Add(this.richTextBox25, 1, 4);
            this.tableLayoutPanel5.Controls.Add(this.label21, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.label22, 0, 1);
            this.tableLayoutPanel5.Controls.Add(this.label23, 0, 2);
            this.tableLayoutPanel5.Controls.Add(this.label24, 0, 3);
            this.tableLayoutPanel5.Controls.Add(this.label25, 0, 4);
            this.tableLayoutPanel5.Location = new System.Drawing.Point(692, 231);
            this.tableLayoutPanel5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 6;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(180, 166);
            this.tableLayoutPanel5.TabIndex = 7;
            // 
            // richTextBox21
            // 
            this.richTextBox21.Location = new System.Drawing.Point(92, 2);
            this.richTextBox21.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox21.Name = "richTextBox21";
            this.richTextBox21.Size = new System.Drawing.Size(86, 23);
            this.richTextBox21.TabIndex = 1;
            this.richTextBox21.Text = "";
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(92, 137);
            this.button5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(86, 25);
            this.button5.TabIndex = 0;
            this.button5.Text = "Apply";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // richTextBox22
            // 
            this.richTextBox22.Location = new System.Drawing.Point(92, 29);
            this.richTextBox22.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox22.Name = "richTextBox22";
            this.richTextBox22.Size = new System.Drawing.Size(86, 23);
            this.richTextBox22.TabIndex = 2;
            this.richTextBox22.Text = "";
            // 
            // richTextBox23
            // 
            this.richTextBox23.Location = new System.Drawing.Point(92, 56);
            this.richTextBox23.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox23.Name = "richTextBox23";
            this.richTextBox23.Size = new System.Drawing.Size(86, 23);
            this.richTextBox23.TabIndex = 3;
            this.richTextBox23.Text = "";
            // 
            // richTextBox24
            // 
            this.richTextBox24.Location = new System.Drawing.Point(92, 83);
            this.richTextBox24.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox24.Name = "richTextBox24";
            this.richTextBox24.Size = new System.Drawing.Size(86, 23);
            this.richTextBox24.TabIndex = 4;
            this.richTextBox24.Text = "";
            // 
            // richTextBox25
            // 
            this.richTextBox25.Location = new System.Drawing.Point(92, 110);
            this.richTextBox25.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox25.Name = "richTextBox25";
            this.richTextBox25.Size = new System.Drawing.Size(86, 23);
            this.richTextBox25.TabIndex = 5;
            this.richTextBox25.Text = "";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(2, 0);
            this.label21.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(45, 17);
            this.label21.TabIndex = 6;
            this.label21.Text = "Y axis";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(2, 27);
            this.label22.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(45, 17);
            this.label22.TabIndex = 7;
            this.label22.Text = "X axis";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(2, 54);
            this.label23.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(67, 17);
            this.label23.TabIndex = 8;
            this.label23.Text = "Danger 1";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(2, 81);
            this.label24.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(67, 17);
            this.label24.TabIndex = 9;
            this.label24.Text = "Danger 2";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(2, 108);
            this.label25.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(67, 17);
            this.label25.TabIndex = 10;
            this.label25.Text = "Danger 3";
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 2;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.Controls.Add(this.richTextBox26, 1, 0);
            this.tableLayoutPanel6.Controls.Add(this.button6, 1, 5);
            this.tableLayoutPanel6.Controls.Add(this.richTextBox27, 1, 1);
            this.tableLayoutPanel6.Controls.Add(this.richTextBox28, 1, 2);
            this.tableLayoutPanel6.Controls.Add(this.richTextBox29, 1, 3);
            this.tableLayoutPanel6.Controls.Add(this.richTextBox30, 1, 4);
            this.tableLayoutPanel6.Controls.Add(this.label26, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.label27, 0, 1);
            this.tableLayoutPanel6.Controls.Add(this.label28, 0, 2);
            this.tableLayoutPanel6.Controls.Add(this.label29, 0, 3);
            this.tableLayoutPanel6.Controls.Add(this.label30, 0, 4);
            this.tableLayoutPanel6.Location = new System.Drawing.Point(464, 233);
            this.tableLayoutPanel6.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 6;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(180, 166);
            this.tableLayoutPanel6.TabIndex = 6;
            // 
            // richTextBox26
            // 
            this.richTextBox26.Location = new System.Drawing.Point(92, 2);
            this.richTextBox26.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox26.Name = "richTextBox26";
            this.richTextBox26.Size = new System.Drawing.Size(86, 23);
            this.richTextBox26.TabIndex = 1;
            this.richTextBox26.Text = "";
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(92, 137);
            this.button6.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(86, 25);
            this.button6.TabIndex = 0;
            this.button6.Text = "Apply";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // richTextBox27
            // 
            this.richTextBox27.Location = new System.Drawing.Point(92, 29);
            this.richTextBox27.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox27.Name = "richTextBox27";
            this.richTextBox27.Size = new System.Drawing.Size(86, 23);
            this.richTextBox27.TabIndex = 2;
            this.richTextBox27.Text = "";
            // 
            // richTextBox28
            // 
            this.richTextBox28.Location = new System.Drawing.Point(92, 56);
            this.richTextBox28.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox28.Name = "richTextBox28";
            this.richTextBox28.Size = new System.Drawing.Size(86, 23);
            this.richTextBox28.TabIndex = 3;
            this.richTextBox28.Text = "";
            // 
            // richTextBox29
            // 
            this.richTextBox29.Location = new System.Drawing.Point(92, 83);
            this.richTextBox29.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox29.Name = "richTextBox29";
            this.richTextBox29.Size = new System.Drawing.Size(86, 23);
            this.richTextBox29.TabIndex = 4;
            this.richTextBox29.Text = "";
            // 
            // richTextBox30
            // 
            this.richTextBox30.Location = new System.Drawing.Point(92, 110);
            this.richTextBox30.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox30.Name = "richTextBox30";
            this.richTextBox30.Size = new System.Drawing.Size(86, 23);
            this.richTextBox30.TabIndex = 5;
            this.richTextBox30.Text = "";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(2, 0);
            this.label26.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(45, 17);
            this.label26.TabIndex = 6;
            this.label26.Text = "Y axis";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(2, 27);
            this.label27.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(45, 17);
            this.label27.TabIndex = 7;
            this.label27.Text = "X axis";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(2, 54);
            this.label28.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(67, 17);
            this.label28.TabIndex = 8;
            this.label28.Text = "Danger 1";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(2, 81);
            this.label29.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(67, 17);
            this.label29.TabIndex = 9;
            this.label29.Text = "Danger 2";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(2, 108);
            this.label30.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(67, 17);
            this.label30.TabIndex = 10;
            this.label30.Text = "Danger 3";
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 2;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.Controls.Add(this.richTextBox31, 1, 0);
            this.tableLayoutPanel7.Controls.Add(this.button7, 1, 5);
            this.tableLayoutPanel7.Controls.Add(this.richTextBox32, 1, 1);
            this.tableLayoutPanel7.Controls.Add(this.richTextBox33, 1, 2);
            this.tableLayoutPanel7.Controls.Add(this.richTextBox34, 1, 3);
            this.tableLayoutPanel7.Controls.Add(this.richTextBox35, 1, 4);
            this.tableLayoutPanel7.Controls.Add(this.label31, 0, 0);
            this.tableLayoutPanel7.Controls.Add(this.label32, 0, 1);
            this.tableLayoutPanel7.Controls.Add(this.label33, 0, 2);
            this.tableLayoutPanel7.Controls.Add(this.label34, 0, 3);
            this.tableLayoutPanel7.Controls.Add(this.label35, 0, 4);
            this.tableLayoutPanel7.Location = new System.Drawing.Point(230, 231);
            this.tableLayoutPanel7.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 6;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(180, 166);
            this.tableLayoutPanel7.TabIndex = 5;
            // 
            // richTextBox31
            // 
            this.richTextBox31.Location = new System.Drawing.Point(92, 2);
            this.richTextBox31.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox31.Name = "richTextBox31";
            this.richTextBox31.Size = new System.Drawing.Size(86, 23);
            this.richTextBox31.TabIndex = 1;
            this.richTextBox31.Text = "";
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(92, 137);
            this.button7.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(86, 25);
            this.button7.TabIndex = 0;
            this.button7.Text = "Apply";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // richTextBox32
            // 
            this.richTextBox32.Location = new System.Drawing.Point(92, 29);
            this.richTextBox32.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox32.Name = "richTextBox32";
            this.richTextBox32.Size = new System.Drawing.Size(86, 23);
            this.richTextBox32.TabIndex = 2;
            this.richTextBox32.Text = "";
            // 
            // richTextBox33
            // 
            this.richTextBox33.Location = new System.Drawing.Point(92, 56);
            this.richTextBox33.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox33.Name = "richTextBox33";
            this.richTextBox33.Size = new System.Drawing.Size(86, 23);
            this.richTextBox33.TabIndex = 3;
            this.richTextBox33.Text = "";
            // 
            // richTextBox34
            // 
            this.richTextBox34.Location = new System.Drawing.Point(92, 83);
            this.richTextBox34.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox34.Name = "richTextBox34";
            this.richTextBox34.Size = new System.Drawing.Size(86, 23);
            this.richTextBox34.TabIndex = 4;
            this.richTextBox34.Text = "";
            // 
            // richTextBox35
            // 
            this.richTextBox35.Location = new System.Drawing.Point(92, 110);
            this.richTextBox35.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox35.Name = "richTextBox35";
            this.richTextBox35.Size = new System.Drawing.Size(86, 23);
            this.richTextBox35.TabIndex = 5;
            this.richTextBox35.Text = "";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(2, 0);
            this.label31.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(45, 17);
            this.label31.TabIndex = 6;
            this.label31.Text = "Y axis";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(2, 27);
            this.label32.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(45, 17);
            this.label32.TabIndex = 7;
            this.label32.Text = "X axis";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(2, 54);
            this.label33.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(67, 17);
            this.label33.TabIndex = 8;
            this.label33.Text = "Danger 1";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(2, 81);
            this.label34.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(67, 17);
            this.label34.TabIndex = 9;
            this.label34.Text = "Danger 2";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(2, 108);
            this.label35.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(67, 17);
            this.label35.TabIndex = 10;
            this.label35.Text = "Danger 3";
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 2;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel8.Controls.Add(this.richTextBox36, 1, 0);
            this.tableLayoutPanel8.Controls.Add(this.button8, 1, 5);
            this.tableLayoutPanel8.Controls.Add(this.richTextBox37, 1, 1);
            this.tableLayoutPanel8.Controls.Add(this.richTextBox38, 1, 2);
            this.tableLayoutPanel8.Controls.Add(this.richTextBox39, 1, 3);
            this.tableLayoutPanel8.Controls.Add(this.richTextBox40, 1, 4);
            this.tableLayoutPanel8.Controls.Add(this.label36, 0, 0);
            this.tableLayoutPanel8.Controls.Add(this.label37, 0, 1);
            this.tableLayoutPanel8.Controls.Add(this.label38, 0, 2);
            this.tableLayoutPanel8.Controls.Add(this.label39, 0, 3);
            this.tableLayoutPanel8.Controls.Add(this.label40, 0, 4);
            this.tableLayoutPanel8.Location = new System.Drawing.Point(20, 231);
            this.tableLayoutPanel8.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 6;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(180, 166);
            this.tableLayoutPanel8.TabIndex = 4;
            // 
            // richTextBox36
            // 
            this.richTextBox36.Location = new System.Drawing.Point(92, 2);
            this.richTextBox36.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox36.Name = "richTextBox36";
            this.richTextBox36.Size = new System.Drawing.Size(86, 23);
            this.richTextBox36.TabIndex = 1;
            this.richTextBox36.Text = "";
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(92, 137);
            this.button8.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(86, 25);
            this.button8.TabIndex = 0;
            this.button8.Text = "Apply";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // richTextBox37
            // 
            this.richTextBox37.Location = new System.Drawing.Point(92, 29);
            this.richTextBox37.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox37.Name = "richTextBox37";
            this.richTextBox37.Size = new System.Drawing.Size(86, 23);
            this.richTextBox37.TabIndex = 2;
            this.richTextBox37.Text = "";
            // 
            // richTextBox38
            // 
            this.richTextBox38.Location = new System.Drawing.Point(92, 56);
            this.richTextBox38.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox38.Name = "richTextBox38";
            this.richTextBox38.Size = new System.Drawing.Size(86, 23);
            this.richTextBox38.TabIndex = 3;
            this.richTextBox38.Text = "";
            // 
            // richTextBox39
            // 
            this.richTextBox39.Location = new System.Drawing.Point(92, 83);
            this.richTextBox39.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox39.Name = "richTextBox39";
            this.richTextBox39.Size = new System.Drawing.Size(86, 23);
            this.richTextBox39.TabIndex = 4;
            this.richTextBox39.Text = "";
            // 
            // richTextBox40
            // 
            this.richTextBox40.Location = new System.Drawing.Point(92, 110);
            this.richTextBox40.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox40.Name = "richTextBox40";
            this.richTextBox40.Size = new System.Drawing.Size(86, 23);
            this.richTextBox40.TabIndex = 5;
            this.richTextBox40.Text = "";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(2, 0);
            this.label36.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(45, 17);
            this.label36.TabIndex = 6;
            this.label36.Text = "Y axis";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(2, 27);
            this.label37.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(45, 17);
            this.label37.TabIndex = 7;
            this.label37.Text = "X axis";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(2, 54);
            this.label38.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(67, 17);
            this.label38.TabIndex = 8;
            this.label38.Text = "Danger 1";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(2, 81);
            this.label39.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(67, 17);
            this.label39.TabIndex = 9;
            this.label39.Text = "Danger 2";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(2, 108);
            this.label40.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(67, 17);
            this.label40.TabIndex = 10;
            this.label40.Text = "Danger 3";
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.ColumnCount = 2;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel9.Controls.Add(this.richTextBox41, 1, 0);
            this.tableLayoutPanel9.Controls.Add(this.button9, 1, 5);
            this.tableLayoutPanel9.Controls.Add(this.richTextBox42, 1, 1);
            this.tableLayoutPanel9.Controls.Add(this.richTextBox43, 1, 2);
            this.tableLayoutPanel9.Controls.Add(this.richTextBox44, 1, 3);
            this.tableLayoutPanel9.Controls.Add(this.richTextBox45, 1, 4);
            this.tableLayoutPanel9.Controls.Add(this.label41, 0, 0);
            this.tableLayoutPanel9.Controls.Add(this.label42, 0, 1);
            this.tableLayoutPanel9.Controls.Add(this.label43, 0, 2);
            this.tableLayoutPanel9.Controls.Add(this.label44, 0, 3);
            this.tableLayoutPanel9.Controls.Add(this.label45, 0, 4);
            this.tableLayoutPanel9.Location = new System.Drawing.Point(916, 231);
            this.tableLayoutPanel9.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 6;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(180, 166);
            this.tableLayoutPanel9.TabIndex = 11;
            // 
            // richTextBox41
            // 
            this.richTextBox41.Location = new System.Drawing.Point(92, 2);
            this.richTextBox41.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox41.Name = "richTextBox41";
            this.richTextBox41.Size = new System.Drawing.Size(86, 23);
            this.richTextBox41.TabIndex = 1;
            this.richTextBox41.Text = "";
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(92, 137);
            this.button9.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(86, 25);
            this.button9.TabIndex = 0;
            this.button9.Text = "Apply";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // richTextBox42
            // 
            this.richTextBox42.Location = new System.Drawing.Point(92, 29);
            this.richTextBox42.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox42.Name = "richTextBox42";
            this.richTextBox42.Size = new System.Drawing.Size(86, 23);
            this.richTextBox42.TabIndex = 2;
            this.richTextBox42.Text = "";
            // 
            // richTextBox43
            // 
            this.richTextBox43.Location = new System.Drawing.Point(92, 56);
            this.richTextBox43.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox43.Name = "richTextBox43";
            this.richTextBox43.Size = new System.Drawing.Size(86, 23);
            this.richTextBox43.TabIndex = 3;
            this.richTextBox43.Text = "";
            // 
            // richTextBox44
            // 
            this.richTextBox44.Location = new System.Drawing.Point(92, 83);
            this.richTextBox44.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox44.Name = "richTextBox44";
            this.richTextBox44.Size = new System.Drawing.Size(86, 23);
            this.richTextBox44.TabIndex = 4;
            this.richTextBox44.Text = "";
            // 
            // richTextBox45
            // 
            this.richTextBox45.Location = new System.Drawing.Point(92, 110);
            this.richTextBox45.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox45.Name = "richTextBox45";
            this.richTextBox45.Size = new System.Drawing.Size(86, 23);
            this.richTextBox45.TabIndex = 5;
            this.richTextBox45.Text = "";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(2, 0);
            this.label41.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(45, 17);
            this.label41.TabIndex = 6;
            this.label41.Text = "Y axis";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(2, 27);
            this.label42.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(45, 17);
            this.label42.TabIndex = 7;
            this.label42.Text = "X axis";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(2, 54);
            this.label43.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(67, 17);
            this.label43.TabIndex = 8;
            this.label43.Text = "Danger 1";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(2, 81);
            this.label44.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(67, 17);
            this.label44.TabIndex = 9;
            this.label44.Text = "Danger 2";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(2, 108);
            this.label45.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(67, 17);
            this.label45.TabIndex = 10;
            this.label45.Text = "Danger 3";
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.ColumnCount = 2;
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel10.Controls.Add(this.richTextBox46, 1, 0);
            this.tableLayoutPanel10.Controls.Add(this.button10, 1, 5);
            this.tableLayoutPanel10.Controls.Add(this.richTextBox47, 1, 1);
            this.tableLayoutPanel10.Controls.Add(this.richTextBox48, 1, 2);
            this.tableLayoutPanel10.Controls.Add(this.richTextBox49, 1, 3);
            this.tableLayoutPanel10.Controls.Add(this.richTextBox50, 1, 4);
            this.tableLayoutPanel10.Controls.Add(this.label46, 0, 0);
            this.tableLayoutPanel10.Controls.Add(this.label47, 0, 1);
            this.tableLayoutPanel10.Controls.Add(this.label48, 0, 2);
            this.tableLayoutPanel10.Controls.Add(this.label49, 0, 3);
            this.tableLayoutPanel10.Controls.Add(this.label50, 0, 4);
            this.tableLayoutPanel10.Location = new System.Drawing.Point(464, 426);
            this.tableLayoutPanel10.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 6;
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(180, 166);
            this.tableLayoutPanel10.TabIndex = 10;
            // 
            // richTextBox46
            // 
            this.richTextBox46.Location = new System.Drawing.Point(92, 2);
            this.richTextBox46.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox46.Name = "richTextBox46";
            this.richTextBox46.Size = new System.Drawing.Size(86, 23);
            this.richTextBox46.TabIndex = 1;
            this.richTextBox46.Text = "";
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(92, 137);
            this.button10.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(86, 25);
            this.button10.TabIndex = 0;
            this.button10.Text = "Apply";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // richTextBox47
            // 
            this.richTextBox47.Location = new System.Drawing.Point(92, 29);
            this.richTextBox47.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox47.Name = "richTextBox47";
            this.richTextBox47.Size = new System.Drawing.Size(86, 23);
            this.richTextBox47.TabIndex = 2;
            this.richTextBox47.Text = "";
            // 
            // richTextBox48
            // 
            this.richTextBox48.Location = new System.Drawing.Point(92, 56);
            this.richTextBox48.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox48.Name = "richTextBox48";
            this.richTextBox48.Size = new System.Drawing.Size(86, 23);
            this.richTextBox48.TabIndex = 3;
            this.richTextBox48.Text = "";
            // 
            // richTextBox49
            // 
            this.richTextBox49.Location = new System.Drawing.Point(92, 83);
            this.richTextBox49.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox49.Name = "richTextBox49";
            this.richTextBox49.Size = new System.Drawing.Size(86, 23);
            this.richTextBox49.TabIndex = 4;
            this.richTextBox49.Text = "";
            // 
            // richTextBox50
            // 
            this.richTextBox50.Location = new System.Drawing.Point(92, 110);
            this.richTextBox50.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox50.Name = "richTextBox50";
            this.richTextBox50.Size = new System.Drawing.Size(86, 23);
            this.richTextBox50.TabIndex = 5;
            this.richTextBox50.Text = "";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(2, 0);
            this.label46.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(45, 17);
            this.label46.TabIndex = 6;
            this.label46.Text = "Y axis";
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(2, 27);
            this.label47.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(45, 17);
            this.label47.TabIndex = 7;
            this.label47.Text = "X axis";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(2, 54);
            this.label48.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(67, 17);
            this.label48.TabIndex = 8;
            this.label48.Text = "Danger 1";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(2, 81);
            this.label49.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(67, 17);
            this.label49.TabIndex = 9;
            this.label49.Text = "Danger 2";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(2, 108);
            this.label50.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(67, 17);
            this.label50.TabIndex = 10;
            this.label50.Text = "Danger 3";
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.ColumnCount = 2;
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.Controls.Add(this.richTextBox51, 1, 0);
            this.tableLayoutPanel11.Controls.Add(this.button11, 1, 5);
            this.tableLayoutPanel11.Controls.Add(this.richTextBox52, 1, 1);
            this.tableLayoutPanel11.Controls.Add(this.richTextBox53, 1, 2);
            this.tableLayoutPanel11.Controls.Add(this.richTextBox54, 1, 3);
            this.tableLayoutPanel11.Controls.Add(this.richTextBox55, 1, 4);
            this.tableLayoutPanel11.Controls.Add(this.label51, 0, 0);
            this.tableLayoutPanel11.Controls.Add(this.label52, 0, 1);
            this.tableLayoutPanel11.Controls.Add(this.label53, 0, 2);
            this.tableLayoutPanel11.Controls.Add(this.label54, 0, 3);
            this.tableLayoutPanel11.Controls.Add(this.label55, 0, 4);
            this.tableLayoutPanel11.Location = new System.Drawing.Point(230, 426);
            this.tableLayoutPanel11.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 6;
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(180, 166);
            this.tableLayoutPanel11.TabIndex = 9;
            // 
            // richTextBox51
            // 
            this.richTextBox51.Location = new System.Drawing.Point(92, 2);
            this.richTextBox51.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox51.Name = "richTextBox51";
            this.richTextBox51.Size = new System.Drawing.Size(86, 23);
            this.richTextBox51.TabIndex = 1;
            this.richTextBox51.Text = "";
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(92, 137);
            this.button11.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(86, 25);
            this.button11.TabIndex = 0;
            this.button11.Text = "Apply";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // richTextBox52
            // 
            this.richTextBox52.Location = new System.Drawing.Point(92, 29);
            this.richTextBox52.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox52.Name = "richTextBox52";
            this.richTextBox52.Size = new System.Drawing.Size(86, 23);
            this.richTextBox52.TabIndex = 2;
            this.richTextBox52.Text = "";
            // 
            // richTextBox53
            // 
            this.richTextBox53.Location = new System.Drawing.Point(92, 56);
            this.richTextBox53.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox53.Name = "richTextBox53";
            this.richTextBox53.Size = new System.Drawing.Size(86, 23);
            this.richTextBox53.TabIndex = 3;
            this.richTextBox53.Text = "";
            // 
            // richTextBox54
            // 
            this.richTextBox54.Location = new System.Drawing.Point(92, 83);
            this.richTextBox54.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox54.Name = "richTextBox54";
            this.richTextBox54.Size = new System.Drawing.Size(86, 23);
            this.richTextBox54.TabIndex = 4;
            this.richTextBox54.Text = "";
            // 
            // richTextBox55
            // 
            this.richTextBox55.Location = new System.Drawing.Point(92, 110);
            this.richTextBox55.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox55.Name = "richTextBox55";
            this.richTextBox55.Size = new System.Drawing.Size(86, 23);
            this.richTextBox55.TabIndex = 5;
            this.richTextBox55.Text = "";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(2, 0);
            this.label51.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(45, 17);
            this.label51.TabIndex = 6;
            this.label51.Text = "Y axis";
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(2, 27);
            this.label52.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(45, 17);
            this.label52.TabIndex = 7;
            this.label52.Text = "X axis";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(2, 54);
            this.label53.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(67, 17);
            this.label53.TabIndex = 8;
            this.label53.Text = "Danger 1";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(2, 81);
            this.label54.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(67, 17);
            this.label54.TabIndex = 9;
            this.label54.Text = "Danger 2";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.Location = new System.Drawing.Point(2, 108);
            this.label55.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(67, 17);
            this.label55.TabIndex = 10;
            this.label55.Text = "Danger 3";
            // 
            // tableLayoutPanel12
            // 
            this.tableLayoutPanel12.ColumnCount = 2;
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.Controls.Add(this.richTextBox56, 1, 0);
            this.tableLayoutPanel12.Controls.Add(this.button12, 1, 5);
            this.tableLayoutPanel12.Controls.Add(this.richTextBox57, 1, 1);
            this.tableLayoutPanel12.Controls.Add(this.richTextBox58, 1, 2);
            this.tableLayoutPanel12.Controls.Add(this.richTextBox59, 1, 3);
            this.tableLayoutPanel12.Controls.Add(this.richTextBox60, 1, 4);
            this.tableLayoutPanel12.Controls.Add(this.label56, 0, 0);
            this.tableLayoutPanel12.Controls.Add(this.label57, 0, 1);
            this.tableLayoutPanel12.Controls.Add(this.label58, 0, 2);
            this.tableLayoutPanel12.Controls.Add(this.label59, 0, 3);
            this.tableLayoutPanel12.Controls.Add(this.label60, 0, 4);
            this.tableLayoutPanel12.Location = new System.Drawing.Point(20, 426);
            this.tableLayoutPanel12.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tableLayoutPanel12.Name = "tableLayoutPanel12";
            this.tableLayoutPanel12.RowCount = 6;
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel12.Size = new System.Drawing.Size(180, 166);
            this.tableLayoutPanel12.TabIndex = 8;
            // 
            // richTextBox56
            // 
            this.richTextBox56.Location = new System.Drawing.Point(92, 2);
            this.richTextBox56.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox56.Name = "richTextBox56";
            this.richTextBox56.Size = new System.Drawing.Size(86, 23);
            this.richTextBox56.TabIndex = 1;
            this.richTextBox56.Text = "";
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(92, 137);
            this.button12.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(86, 25);
            this.button12.TabIndex = 0;
            this.button12.Text = "Apply";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // richTextBox57
            // 
            this.richTextBox57.Location = new System.Drawing.Point(92, 29);
            this.richTextBox57.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox57.Name = "richTextBox57";
            this.richTextBox57.Size = new System.Drawing.Size(86, 23);
            this.richTextBox57.TabIndex = 2;
            this.richTextBox57.Text = "";
            // 
            // richTextBox58
            // 
            this.richTextBox58.Location = new System.Drawing.Point(92, 56);
            this.richTextBox58.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox58.Name = "richTextBox58";
            this.richTextBox58.Size = new System.Drawing.Size(86, 23);
            this.richTextBox58.TabIndex = 3;
            this.richTextBox58.Text = "";
            // 
            // richTextBox59
            // 
            this.richTextBox59.Location = new System.Drawing.Point(92, 83);
            this.richTextBox59.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox59.Name = "richTextBox59";
            this.richTextBox59.Size = new System.Drawing.Size(86, 23);
            this.richTextBox59.TabIndex = 4;
            this.richTextBox59.Text = "";
            // 
            // richTextBox60
            // 
            this.richTextBox60.Location = new System.Drawing.Point(92, 110);
            this.richTextBox60.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox60.Name = "richTextBox60";
            this.richTextBox60.Size = new System.Drawing.Size(86, 23);
            this.richTextBox60.TabIndex = 5;
            this.richTextBox60.Text = "";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.Location = new System.Drawing.Point(2, 0);
            this.label56.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(45, 17);
            this.label56.TabIndex = 6;
            this.label56.Text = "Y axis";
            this.label56.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.Location = new System.Drawing.Point(2, 27);
            this.label57.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(45, 17);
            this.label57.TabIndex = 7;
            this.label57.Text = "X axis";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.Location = new System.Drawing.Point(2, 54);
            this.label58.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(67, 17);
            this.label58.TabIndex = 8;
            this.label58.Text = "Danger 1";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.Location = new System.Drawing.Point(2, 81);
            this.label59.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(67, 17);
            this.label59.TabIndex = 9;
            this.label59.Text = "Danger 2";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.Location = new System.Drawing.Point(2, 108);
            this.label60.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(67, 17);
            this.label60.TabIndex = 10;
            this.label60.Text = "Danger 3";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.Location = new System.Drawing.Point(18, 5);
            this.label61.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(40, 18);
            this.label61.TabIndex = 12;
            this.label61.Text = "H2S";
            this.label61.Click += new System.EventHandler(this.label61_Click);
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label62.Location = new System.Drawing.Point(227, 5);
            this.label62.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(44, 18);
            this.label62.TabIndex = 13;
            this.label62.Text = "HCN";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label63.Location = new System.Drawing.Point(460, 5);
            this.label63.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(41, 18);
            this.label63.TabIndex = 14;
            this.label63.Text = "HCL";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.Location = new System.Drawing.Point(688, 5);
            this.label64.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(69, 18);
            this.label64.TabIndex = 15;
            this.label64.Text = "NO2-AE";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label65.Location = new System.Drawing.Point(18, 204);
            this.label65.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(41, 18);
            this.label65.TabIndex = 16;
            this.label65.Text = "SO2";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.Location = new System.Drawing.Point(227, 204);
            this.label66.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(60, 18);
            this.label66.TabIndex = 17;
            this.label66.Text = "PID-A1";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.Location = new System.Drawing.Point(460, 204);
            this.label67.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(59, 18);
            this.label67.TabIndex = 18;
            this.label67.Text = "CH-D3";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.Location = new System.Drawing.Point(688, 204);
            this.label68.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(58, 18);
            this.label68.TabIndex = 19;
            this.label68.Text = "NO-A1";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label69.Location = new System.Drawing.Point(912, 207);
            this.label69.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(80, 18);
            this.label69.TabIndex = 23;
            this.label69.Text = "CO-AF(2)";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label70.Location = new System.Drawing.Point(460, 402);
            this.label70.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(80, 18);
            this.label70.TabIndex = 22;
            this.label70.Text = "CO-AF(1)";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label71.Location = new System.Drawing.Point(227, 402);
            this.label71.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(61, 18);
            this.label71.TabIndex = 21;
            this.label71.Text = "IRC-A1";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label72.Location = new System.Drawing.Point(18, 402);
            this.label72.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(63, 18);
            this.label72.TabIndex = 20;
            this.label72.Text = "CL2-A1";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label73.Location = new System.Drawing.Point(913, 8);
            this.label73.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(41, 18);
            this.label73.TabIndex = 25;
            this.label73.Text = "NH3";
            // 
            // tableLayoutPanel13
            // 
            this.tableLayoutPanel13.ColumnCount = 2;
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel13.Controls.Add(this.richTextBox61, 1, 0);
            this.tableLayoutPanel13.Controls.Add(this.button13, 1, 5);
            this.tableLayoutPanel13.Controls.Add(this.richTextBox62, 1, 1);
            this.tableLayoutPanel13.Controls.Add(this.richTextBox63, 1, 2);
            this.tableLayoutPanel13.Controls.Add(this.richTextBox64, 1, 3);
            this.tableLayoutPanel13.Controls.Add(this.richTextBox65, 1, 4);
            this.tableLayoutPanel13.Controls.Add(this.label74, 0, 0);
            this.tableLayoutPanel13.Controls.Add(this.label75, 0, 1);
            this.tableLayoutPanel13.Controls.Add(this.label76, 0, 2);
            this.tableLayoutPanel13.Controls.Add(this.label77, 0, 3);
            this.tableLayoutPanel13.Controls.Add(this.label78, 0, 4);
            this.tableLayoutPanel13.Location = new System.Drawing.Point(915, 32);
            this.tableLayoutPanel13.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tableLayoutPanel13.Name = "tableLayoutPanel13";
            this.tableLayoutPanel13.RowCount = 6;
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel13.Size = new System.Drawing.Size(180, 166);
            this.tableLayoutPanel13.TabIndex = 24;
            // 
            // richTextBox61
            // 
            this.richTextBox61.Location = new System.Drawing.Point(92, 2);
            this.richTextBox61.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox61.Name = "richTextBox61";
            this.richTextBox61.Size = new System.Drawing.Size(86, 23);
            this.richTextBox61.TabIndex = 1;
            this.richTextBox61.Text = "";
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(92, 137);
            this.button13.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(86, 25);
            this.button13.TabIndex = 0;
            this.button13.Text = "Apply";
            this.button13.UseVisualStyleBackColor = true;
            // 
            // richTextBox62
            // 
            this.richTextBox62.Location = new System.Drawing.Point(92, 29);
            this.richTextBox62.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox62.Name = "richTextBox62";
            this.richTextBox62.Size = new System.Drawing.Size(86, 23);
            this.richTextBox62.TabIndex = 2;
            this.richTextBox62.Text = "";
            // 
            // richTextBox63
            // 
            this.richTextBox63.Location = new System.Drawing.Point(92, 56);
            this.richTextBox63.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox63.Name = "richTextBox63";
            this.richTextBox63.Size = new System.Drawing.Size(86, 23);
            this.richTextBox63.TabIndex = 3;
            this.richTextBox63.Text = "";
            // 
            // richTextBox64
            // 
            this.richTextBox64.Location = new System.Drawing.Point(92, 83);
            this.richTextBox64.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox64.Name = "richTextBox64";
            this.richTextBox64.Size = new System.Drawing.Size(86, 23);
            this.richTextBox64.TabIndex = 4;
            this.richTextBox64.Text = "";
            // 
            // richTextBox65
            // 
            this.richTextBox65.Location = new System.Drawing.Point(92, 110);
            this.richTextBox65.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox65.Name = "richTextBox65";
            this.richTextBox65.Size = new System.Drawing.Size(86, 23);
            this.richTextBox65.TabIndex = 5;
            this.richTextBox65.Text = "";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label74.Location = new System.Drawing.Point(2, 0);
            this.label74.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(45, 17);
            this.label74.TabIndex = 6;
            this.label74.Text = "Y axis";
            this.label74.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label75.Location = new System.Drawing.Point(2, 27);
            this.label75.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(45, 17);
            this.label75.TabIndex = 7;
            this.label75.Text = "X axis";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label76.Location = new System.Drawing.Point(2, 54);
            this.label76.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(67, 17);
            this.label76.TabIndex = 8;
            this.label76.Text = "Danger 1";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label77.Location = new System.Drawing.Point(2, 81);
            this.label77.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(67, 17);
            this.label77.TabIndex = 9;
            this.label77.Text = "Danger 2";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label78.Location = new System.Drawing.Point(2, 108);
            this.label78.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(67, 17);
            this.label78.TabIndex = 10;
            this.label78.Text = "Danger 3";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1110, 602);
            this.Controls.Add(this.label73);
            this.Controls.Add(this.tableLayoutPanel13);
            this.Controls.Add(this.label69);
            this.Controls.Add(this.label70);
            this.Controls.Add(this.label71);
            this.Controls.Add(this.label72);
            this.Controls.Add(this.label68);
            this.Controls.Add(this.label67);
            this.Controls.Add(this.label66);
            this.Controls.Add(this.label65);
            this.Controls.Add(this.label64);
            this.Controls.Add(this.label63);
            this.Controls.Add(this.label62);
            this.Controls.Add(this.label61);
            this.Controls.Add(this.tableLayoutPanel9);
            this.Controls.Add(this.tableLayoutPanel10);
            this.Controls.Add(this.tableLayoutPanel11);
            this.Controls.Add(this.tableLayoutPanel12);
            this.Controls.Add(this.tableLayoutPanel5);
            this.Controls.Add(this.tableLayoutPanel6);
            this.Controls.Add(this.tableLayoutPanel7);
            this.Controls.Add(this.tableLayoutPanel8);
            this.Controls.Add(this.tableLayoutPanel4);
            this.Controls.Add(this.tableLayoutPanel3);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.MaximizeBox = false;
            this.Name = "Form2";
            this.Text = "Options";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel7.PerformLayout();
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel8.PerformLayout();
            this.tableLayoutPanel9.ResumeLayout(false);
            this.tableLayoutPanel9.PerformLayout();
            this.tableLayoutPanel10.ResumeLayout(false);
            this.tableLayoutPanel10.PerformLayout();
            this.tableLayoutPanel11.ResumeLayout(false);
            this.tableLayoutPanel11.PerformLayout();
            this.tableLayoutPanel12.ResumeLayout(false);
            this.tableLayoutPanel12.PerformLayout();
            this.tableLayoutPanel13.ResumeLayout(false);
            this.tableLayoutPanel13.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.RichTextBox richTextBox3;
        private System.Windows.Forms.RichTextBox richTextBox4;
        private System.Windows.Forms.RichTextBox richTextBox5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.RichTextBox richTextBox6;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.RichTextBox richTextBox7;
        private System.Windows.Forms.RichTextBox richTextBox8;
        private System.Windows.Forms.RichTextBox richTextBox9;
        private System.Windows.Forms.RichTextBox richTextBox10;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.RichTextBox richTextBox11;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.RichTextBox richTextBox12;
        private System.Windows.Forms.RichTextBox richTextBox13;
        private System.Windows.Forms.RichTextBox richTextBox14;
        private System.Windows.Forms.RichTextBox richTextBox15;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.RichTextBox richTextBox16;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.RichTextBox richTextBox17;
        private System.Windows.Forms.RichTextBox richTextBox18;
        private System.Windows.Forms.RichTextBox richTextBox19;
        private System.Windows.Forms.RichTextBox richTextBox20;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.RichTextBox richTextBox21;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.RichTextBox richTextBox22;
        private System.Windows.Forms.RichTextBox richTextBox23;
        private System.Windows.Forms.RichTextBox richTextBox24;
        private System.Windows.Forms.RichTextBox richTextBox25;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.RichTextBox richTextBox26;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.RichTextBox richTextBox27;
        private System.Windows.Forms.RichTextBox richTextBox28;
        private System.Windows.Forms.RichTextBox richTextBox29;
        private System.Windows.Forms.RichTextBox richTextBox30;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.RichTextBox richTextBox31;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.RichTextBox richTextBox32;
        private System.Windows.Forms.RichTextBox richTextBox33;
        private System.Windows.Forms.RichTextBox richTextBox34;
        private System.Windows.Forms.RichTextBox richTextBox35;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.RichTextBox richTextBox36;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.RichTextBox richTextBox37;
        private System.Windows.Forms.RichTextBox richTextBox38;
        private System.Windows.Forms.RichTextBox richTextBox39;
        private System.Windows.Forms.RichTextBox richTextBox40;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private System.Windows.Forms.RichTextBox richTextBox41;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.RichTextBox richTextBox42;
        private System.Windows.Forms.RichTextBox richTextBox43;
        private System.Windows.Forms.RichTextBox richTextBox44;
        private System.Windows.Forms.RichTextBox richTextBox45;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel10;
        private System.Windows.Forms.RichTextBox richTextBox46;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.RichTextBox richTextBox47;
        private System.Windows.Forms.RichTextBox richTextBox48;
        private System.Windows.Forms.RichTextBox richTextBox49;
        private System.Windows.Forms.RichTextBox richTextBox50;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel11;
        private System.Windows.Forms.RichTextBox richTextBox51;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.RichTextBox richTextBox52;
        private System.Windows.Forms.RichTextBox richTextBox53;
        private System.Windows.Forms.RichTextBox richTextBox54;
        private System.Windows.Forms.RichTextBox richTextBox55;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel12;
        private System.Windows.Forms.RichTextBox richTextBox56;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.RichTextBox richTextBox57;
        private System.Windows.Forms.RichTextBox richTextBox58;
        private System.Windows.Forms.RichTextBox richTextBox59;
        private System.Windows.Forms.RichTextBox richTextBox60;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel13;
        private System.Windows.Forms.RichTextBox richTextBox61;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.RichTextBox richTextBox62;
        private System.Windows.Forms.RichTextBox richTextBox63;
        private System.Windows.Forms.RichTextBox richTextBox64;
        private System.Windows.Forms.RichTextBox richTextBox65;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label78;
    }
}